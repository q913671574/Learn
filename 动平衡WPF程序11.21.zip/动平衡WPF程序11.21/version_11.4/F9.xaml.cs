﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace version_11._4
{
    /// <summary>
    /// F9.xaml 的交互逻辑
    /// </summary>
    public partial class F9 : Window
    {
        public F9()
        {
            InitializeComponent();
        }

        private void bt_exit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.opened = false;
            this.Close();
        }
    }
}
