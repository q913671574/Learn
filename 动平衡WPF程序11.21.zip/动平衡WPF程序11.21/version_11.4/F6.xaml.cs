﻿using System.Windows;

namespace version_11._4
{
    /// <summary>
    /// F6.xaml 的交互逻辑
    /// </summary>
    public partial class F6 : Window
    {
        public static bool ISO_show = true;
        public F6()
        {
            InitializeComponent();
        }

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.opened = false;
            this.Close();
        }

        private void bt_ISO_Click(object sender, RoutedEventArgs e)
        {
            if (ISO_show)
            {
                ISO1940 ISO = new ISO1940();
                ISO.Show();
                ISO_show = false;
            }
        }

        private void comboBox_direction_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }

        private void NumericControl_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
