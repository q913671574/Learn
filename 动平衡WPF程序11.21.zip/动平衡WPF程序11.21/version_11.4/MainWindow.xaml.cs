﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace version_11._4
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public static bool opened = false;
        public MainWindow()
        {
            InitializeComponent();
            
        }

        
        
        private void F6_Click(object sender, RoutedEventArgs e)
        {

            if (!opened)
            {
                F6 f6 = new F6();
                f6.Owner = this;
                f6.Show();
                opened = true;

            }
           
        }

        private void F9_Click(object sender, RoutedEventArgs e)
        {
            if (!opened)
            {
                F9 f9 = new F9();
                f9.Owner = this;
                f9.Show();
                opened = true;

            }
        }

        private void F8_Click(object sender, RoutedEventArgs e)
        {
            if (!opened)
            {
                F8 f8 = new F8();
                f8.Owner = this;
                f8.Show();
                opened = true;

            }
        }

        private void F2_Click(object sender, RoutedEventArgs e)
        {
            if (!opened)
            {
                F2 f2 = new F2();
                f2.Owner = this;
                f2.Show();
                opened = true;
            }
        }

        private void F5_Click(object sender, RoutedEventArgs e)
        {

        }

        private void F4_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void F1_Click(object sender, RoutedEventArgs e)
        {
            if (!opened)
            {
                F1 f1 = new F1();
                f1.Owner = this;
                f1.Show();
                opened = true;
            }
        }
    }
}
