﻿using System;

using System.ComponentModel;

using System.Windows;

using System.Windows.Data;



namespace Sample

{
    public partial class NumericControl : INotifyPropertyChanged

    {
        private double numericValue = 1;



        public NumericControl()

        {
            this.InitializeComponent();

        }



        public double Value

        {
            get { return numericValue; }

            set

            {
                numericValue = value;

                NotifyPropertyChanged("Value");

            }

        }

        public double Increment { get; set; }

        public double MaxValue { get; set; }

        public double MinValue { get; set; }



        private void UpButton_Click(object sender, RoutedEventArgs e)

        {
            double newValue = (Value + Increment);

            if (newValue > MaxValue)

            {
                Value = MaxValue;

            }

            else

            {
                Value = newValue;

            }

        }



        private void DownButton_Click(object sender, RoutedEventArgs e)

        {
            double newValue = (Value - Increment);

            if (newValue < MinValue)

            {
                Value = MinValue;

            }

            else

            {
                Value = newValue;

            }

        }



        private void ValueText_LostFocus(object sender, RoutedEventArgs e)

        {
            try

            {
                Value = double.Parse(ValueText.Text);

            }

            catch (Exception)

            {
                Value = 0;

            }

        }





        #region INotifyPropertyChanged Members



        public event PropertyChangedEventHandler PropertyChanged;



        public void NotifyPropertyChanged(string propertyName)

        {
            if (PropertyChanged != null)

            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));

            }

        }



        #endregion

    }



    [ValueConversion(typeof(double), typeof(string))]

    public class DoubleValueConverter : IValueConverter

    {
        #region IValueConverter Members



        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)

        {
            try

            {
                return value.ToString();

            }

            catch (Exception)

            {
                return "0";

            }

        }



        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)

        {
            try

            {
                return double.Parse((string)value);

            }

            catch (Exception)

            {
                return 0;

            }

        }



        #endregion

    }

}